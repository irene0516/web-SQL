<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="UTF-8">
    <title>資料中心</title>
</head>
<body background="bg1.jpg" style="font-size: 20px">
<form name="form" method="post" action="register_finish.php">
    帳號：<input type="text" name="id" /> <br><br>
    密碼：<input type="password" name="pw" /> <br><br>
    再一次輸入密碼：<input type="password" name="pw2" /> <br><br>
    信箱：<input type="text" name="email" /> <br><br>
    電話：<input type="text" name="phone" /> <br><br>
    備註：<textarea name="type" cols="45" rows="5"></textarea> <br><br>
    <input type="submit" name="button" value="確定" />

</form>
</body>
</html>